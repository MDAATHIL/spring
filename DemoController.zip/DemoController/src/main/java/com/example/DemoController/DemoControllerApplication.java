package com.example.DemoController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoControllerApplication.class, args);
	}

}
