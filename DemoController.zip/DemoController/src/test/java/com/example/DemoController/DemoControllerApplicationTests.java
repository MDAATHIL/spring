package com.example.DemoController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
