package com.example.courseRegistration.controller;


import com.example.courseRegistration.model.courseModel;
import com.example.courseRegistration.service.courseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class courseController {

    @Autowired
    courseService c;

    @GetMapping("courses")
    public List<courseModel> getAllcourse(){
        return c.getAllcourse();
    }

    @PostMapping("courses")
    public String addcourses(@RequestBody courseModel cou)
    {
        c.addcourses(cou);
        return "added";
    }

    @GetMapping("courses/{no}")
    public courseModel getcourseById(@PathVariable("id") int id){
        return c.getcourseById(id);
    }

    @PutMapping("courses")
    public String updatecourse(@RequestBody courseModel cou)
    {
        c.updatecourse(cou);
        return "updated successfully";
    }

    @DeleteMapping("courses/{no}")
    public void deletecourse(@PathVariable("id") int id){
        c.deletecourse(id);
    }

    @DeleteMapping("courses/clear")
    public String deleteAll()
    {
        c.deleteAllcourses();
        return "Deleted for ever";
    }








}
