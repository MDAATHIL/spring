package com.example.courseRegistration.controller;

import com.example.courseRegistration.model.enrollmentModel;
import com.example.courseRegistration.service.enrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class enrollmentController {
    @Autowired
    enrollmentService e;

    @GetMapping("/enrollments")
    public List<enrollmentModel> getAllenrollments() {
        return e.getAllenrollments();
    }

    @PostMapping("/enrollments")
    public String addenrollments(@RequestBody enrollmentModel enr)
    {
        e.addenrollments(enr);
        return "added";
    }

    @GetMapping("enrollments/{no}")
    public enrollmentModel getenrollmentById(@PathVariable("id") int id)
    {
        return e.getenrollmentById(id);
    }

    @PutMapping("enrollments")
    public String updateenrollment(@RequestBody enrollmentModel enr)
    {
        e.updateenrollment(enr);
        return "Updated Successfully";
    }

    @DeleteMapping("enrollments/{no}")
    public void deleteenrollment(@PathVariable("id") int id)
    {
        e.deleteenrollment(id);
    }
}


