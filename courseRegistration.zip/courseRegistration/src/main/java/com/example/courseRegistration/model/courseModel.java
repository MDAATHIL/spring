package com.example.courseRegistration.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

public class courseModel {
    @Id
    private int id;
    private String course_name;
    private int duration;
    private String trainer;
}
