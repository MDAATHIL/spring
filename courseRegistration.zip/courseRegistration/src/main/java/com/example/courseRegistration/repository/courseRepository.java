package com.example.courseRegistration.repository;

import com.example.courseRegistration.model.courseModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.lang.ScopedValue;
import java.util.List;

public interface courseRepository extends JpaRepository<courseModel, Integer>{



}
