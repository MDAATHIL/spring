package com.example.courseRegistration.repository;

import com.example.courseRegistration.model.enrollmentModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface enrollmentRepository extends JpaRepository<enrollmentModel, Integer>{



}
