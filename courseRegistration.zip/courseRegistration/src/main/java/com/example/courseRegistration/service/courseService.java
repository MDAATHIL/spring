package com.example.courseRegistration.service;

import com.example.courseRegistration.model.courseModel;
import com.example.courseRegistration.repository.courseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class courseService {
    
    @Autowired
    courseRepository cr;
    
    public List<courseModel> getAllcourse() {
        return cr.findAll();
    }

    public void addcourses(courseModel cou) {
        cr.save(cou);
    }

    public courseModel getcourseById(int id) {
        return (courseModel) cr.findById(id).orElse(null);

    }

    public void updatecourse(courseModel cou) {
        cr.save(cou);

    }

    public void deletecourse(int id) {
        cr.deleteById(id);

    }

    public void deleteAllcourses() {
        cr.deleteAll();

    }
}
