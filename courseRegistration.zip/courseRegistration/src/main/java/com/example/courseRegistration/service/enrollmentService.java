package com.example.courseRegistration.service;

import com.example.courseRegistration.model.enrollmentModel;
import com.example.courseRegistration.repository.enrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class enrollmentService {

    @Autowired
    enrollmentRepository er;

    public List<enrollmentModel> getAllenrollments() {
        return er.findAll();
    }


    public void addenrollments(enrollmentModel enr) {
        er.save(enr);
    }


    public enrollmentModel getenrollmentById(int id) {
        return er.findById(id).orElse(null);
    }


    public enrollmentModel updateenrollment(enrollmentModel enr) {
        return er.save(enr);

    }

    public String deleteenrollment(int id) {
        er.deleteById(id);
        return "Deleted";

    }
}
