package com.example.courseRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
