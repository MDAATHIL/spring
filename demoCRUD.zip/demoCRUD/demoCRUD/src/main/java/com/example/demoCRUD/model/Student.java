package com.example.demoCRUD.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Student {

    private int no;
    private String name;
    private String tech;

}




