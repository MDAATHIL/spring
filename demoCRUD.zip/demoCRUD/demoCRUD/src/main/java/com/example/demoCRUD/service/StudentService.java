package com.example.demoCRUD.service;

import com.example.demoCRUD.model.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class StudentService {

    List<Student> s = new ArrayList<>(
    Arrays.asList(
            new Student(1,"Aathil","Hecker"),
            new Student(2,"Suganth","Web Destroyer"))

    );


    public List<Student> getStudent() {

        return s;

    }

    public Student getStudentByRollno(int rollno){
        int index=0;
        boolean flag=false;
        for(int i=0;i<s.size();i++)
        {
            if(s.get(i).getNo()==rollno)
            {
                index=i;
                flag=true;
                break;
            }
        }
        if(flag)
        {
            return s.get(index);


        }
        else{

            return new Student(0,null,null);

        }

    }

    public String setStudents(Student student) {
        s.add(student);
        return "sucess";
    }

    public String updateStudent(Student student) {
        int index=0;
        boolean flag=false;
        for(int i=0;i<s.size();i++)
        {
            if(s.get(i).getNo()== student.getNo())
            {
                index=i;
                flag = true;
                break;
            }
        }
        if(flag)
        {

             s.set(index,student);

             return "updated Sucessfully";
        }
        else{
            return "Updated failed";
        }

    }

    public String deleteStudents(int no) {
        int index = 0;
        boolean flag = false;
        for(int i=0;i<s.size();i++)
        {
            if(s.get(i).getNo() == no)
            {
                index=i;
                flag=true;
                break;
            }
        }
        if(flag)
        {

            s.remove(index);

            return "Deleted Sucessfully";
        }
        else{
            return "delete failed";
        }

    }

}

