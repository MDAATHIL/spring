package com.example.demoJPA_actual.controller;


import com.example.demoJPA_actual.model.StudentModel;
import com.example.demoJPA_actual.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class StudentController {

    @Autowired
    StudentService s;

    @GetMapping("Students")
    public List<StudentModel> getAllStudent()
    {
        return s.getAllStudents();
    }


    @PostMapping("Students")
    public String addStudents(@RequestBody StudentModel stu)
    {
        s.addStudents(stu);
        return "added";
    }

    @GetMapping("Students/{no}")
    public StudentModel getStudentByRollno(@PathVariable("no") int no) {
        return s.getStudentByRollno(no);
    }

    @PutMapping("Students")
    public String updateStudent(@RequestBody StudentModel stu)
    {
        s.updateStudent(stu);
        return "Updated Successfully";

    }

    @DeleteMapping("Students/{no}")
    public void deleteStudent(@PathVariable("no") int no)
    {
        s.deleteStudent(no);
    }


    @DeleteMapping("Students/clear")
    public String deleteAll()
    {
        s.deleteAllStudents();
        return "Deleted For ever";
    }


    @GetMapping("/Students/technology/{tech}")
    public List<StudentModel> getStudentByTechnology(@PathVariable("tech") String tech) {
        return s.getStudentByTechnology(tech);
    }

    @PostMapping("/Students/technology/filter")
    public List<StudentModel> getStudentByTechnologyAndGender(
            @RequestParam String tech,
            @RequestParam String gender) {

        return s.getStudentByTechnologyAndGender(tech, gender);
    }












}
