package com.example.demoJPA_actual.repository;

import com.example.demoJPA_actual.model.StudentModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface StudentRepository extends JpaRepository<StudentModel, Integer> {

    


    List<StudentModel> findByTech(String tech);

//    List<StudentModel> findByTechAndGender(String tech, String gender);
    @Query(value = "SELECT * FROM student_model WHERE tech = :tech AND gender = :gender", nativeQuery = true)
    List<StudentModel> getByTechAndGender(@Param("tech") String tech,
                                          @Param("gender") String gender);

}
