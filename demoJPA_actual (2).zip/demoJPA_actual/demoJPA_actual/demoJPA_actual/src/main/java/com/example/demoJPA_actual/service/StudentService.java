package com.example.demoJPA_actual.service;

import com.example.demoJPA_actual.model.StudentModel;
import com.example.demoJPA_actual.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    StudentRepository sr;

    public List<StudentModel> getAllStudents() {
        return sr.findAll();
    }

    public void addStudents(StudentModel stu) {
        sr.save(stu);
    }

    public StudentModel getStudentByRollno(int no) {
        return sr.findById(no).orElse(null);
    }

    public StudentModel updateStudent(StudentModel stu) {
        return sr.save(stu);
    }

    public String deleteStudent(int no) {
        sr.deleteById(no);
        return "Deleted";
    }

    public void deleteAllStudents() {
        sr.deleteAll();
    }

    // 🔹 By Technology
    public List<StudentModel> getStudentByTechnology(String tech) {
        return sr.findByTech(tech);
    }

    // 🔹 By Technology AND Gender
    public List<StudentModel> getStudentByTechnologyAndGender(String tech, String gender) {
        return sr.getByTechAndGender(tech, gender);
    }
}

