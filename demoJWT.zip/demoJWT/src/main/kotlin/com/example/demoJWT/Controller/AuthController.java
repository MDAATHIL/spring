package com.example.demoJWT.Controller;

import com.example.demoJWT.Dto.LoginRequest;
import com.example.demoJWT.Utility.JwtUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController {

    public String login(@RequestBody LoginRequest request){

        //Dummy
        if("Aathil".equals(request.getUsername()) && "1234".equals(request.getPassword()))
        {
            return  JwtUtil.generateToken(request.getUsername());
        }
        return "invalid credentials";
    }

    @GetMapping("/hello")
    public String hello(@RequestHeader ("Authorization") String token)
    {
        String username = JwtUtil.validateToken(token.replace("Bearer",""));
        return "Hello"+username;
    }

}
