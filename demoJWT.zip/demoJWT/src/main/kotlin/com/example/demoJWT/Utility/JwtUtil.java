package com.example.demoJWT.Utility;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;

public class JwtUtil {

    private static final String SECRET = "andda kakasam abbukasam thirathudu seesa";

    // Generate JWT
    public static String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 300)) // 5 minutes
                .signWith(SignatureAlgorithm.HS256, SECRET)
                .compact();
    }

    // Validate JWT & extract username
    public static String validateToken(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(SECRET)
                .parseClaimsJws(token)
                .getBody();

        return claims.getSubject(); // returns username
    }
}
