package com.example.demoOAuth2

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DemoOAuth2ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
